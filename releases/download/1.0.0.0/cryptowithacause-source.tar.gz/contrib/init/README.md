Sample configuration files for:
```
SystemD: cryptowithacaused.service
Upstart: cryptowithacaused.conf
OpenRC:  cryptowithacaused.openrc
         cryptowithacaused.openrcconf
CentOS:  cryptowithacaused.init
macOS:    org.cryptowithacause.cryptowithacaused.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
